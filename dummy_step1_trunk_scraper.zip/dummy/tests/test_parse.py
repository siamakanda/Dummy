import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from parse import extract_trunks, carrier_name

HTML = """
<html><head><title>Portal</title></head><body>
<h2>Carrier: BTCL</h2>
<table id="nav"><tr><td>menu</td></tr></table>
<table>
 <thead><tr><th>ID</th><th>Trunk Name</th><th>Status</th></tr></thead>
 <tbody>
  <tr><td>7</td><td><a href="trunk_edit?id=7">BTCL TNT TRUNK</a></td><td>Active</td></tr>
  <tr><td>8</td><td><a href="trunk_edit?id=8">BTCL  STD</a></td><td>Disabled</td></tr>
  <tr><td>9</td><td></td><td>x</td></tr>
 </tbody>
</table></body></html>"""

def test_extract():
    t = extract_trunks(HTML)
    assert [x["trunk_name"] for x in t] == ["BTCL TNT TRUNK", "BTCL STD"]
    assert [x["trunk_id"] for x in t] == ["7", "8"]
    assert not t[0]["column_guess"]
    assert carrier_name(HTML, "x") == "Carrier: BTCL"

def test_override_and_empty():
    assert extract_trunks("<html></html>") == []
    t = extract_trunks(HTML, override="status")
    assert t[0]["trunk_name"] == "Active"
