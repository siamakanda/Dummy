"""Pure HTML parsing (no browser) so it can be unit-tested and tuned from saved snapshots."""
import re
from bs4 import BeautifulSoup

def _txt(el) -> str:
    return re.sub(r"\s+", " ", el.get_text(" ", strip=True)).strip()

def parse_tables(html: str) -> list[dict]:
    """Return [{'headers': [...], 'rows': [{'cells': [...], 'links': [...]}]}] for every <table>."""
    soup = BeautifulSoup(html, "html.parser")
    out = []
    for t in soup.find_all("table"):
        trs = t.find_all("tr")
        if not trs:
            continue
        headers, body = [], []
        for tr in trs:
            ths = tr.find_all("th")
            tds = tr.find_all("td")
            if ths and not tds and not headers:
                headers = [_txt(h) for h in ths]
            elif tds:
                body.append({
                    "cells": [_txt(c) for c in tds],
                    "links": [a.get("href", "") for a in tr.find_all("a") if a.get("href")],
                })
        if body:
            out.append({"headers": headers, "rows": body})
    return out

def carrier_name(html: str, fallback: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    for tag in ("h1", "h2", "h3"):
        el = soup.find(tag)
        if el and _txt(el):
            return _txt(el)
    if soup.title and _txt(soup.title):
        return _txt(soup.title)
    return fallback

def _trunk_col(headers: list[str], override: str) -> int | None:
    low = [h.lower() for h in headers]
    if override:
        for i, h in enumerate(low):
            if h == override:
                return i
    for i, h in enumerate(low):          # best: header mentions both words
        if "trunk" in h and "name" in h:
            return i
    for i, h in enumerate(low):
        if "trunk" in h:
            return i
    for i, h in enumerate(low):
        if h in ("name", "description"):
            return i
    return None

def extract_trunks(html: str, override: str = "") -> list[dict]:
    """Pick the table that looks like the trunk list and return one dict per trunk."""
    tables = parse_tables(html)
    if not tables:
        return []
    def score(t):
        return (any("trunk" in h.lower() for h in t["headers"]), len(t["rows"]))
    best = max(tables, key=score)
    col = _trunk_col(best["headers"], override)
    if col is None:
        col = 0   # last resort; flagged in output via column_guess
    guess = not any("trunk" in h.lower() for h in best["headers"]) and not override
    results = []
    for r in best["rows"]:
        if col >= len(r["cells"]) or not r["cells"][col]:
            continue
        trunk_id = ""
        for href in r["links"]:
            m = re.search(r"[?&]id=(\d+)", href)
            if m:
                trunk_id = m.group(1)
                break
        raw = dict(zip(best["headers"], r["cells"])) if best["headers"] else {"cells": r["cells"]}
        results.append({"trunk_name": r["cells"][col], "trunk_id": trunk_id,
                        "column_guess": guess, "raw": raw})
    return results
