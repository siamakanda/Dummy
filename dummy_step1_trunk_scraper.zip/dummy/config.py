import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).parent
load_dotenv(ROOT / ".env")

BASE_URL = os.getenv("PORTAL_BASE_URL", "https://switchportal.instacall.digital").rstrip("/")
USERNAME = os.getenv("PORTAL_USERNAME", "")
PASSWORD = os.getenv("PORTAL_PASSWORD", "")
TRUNK_NAME_COLUMN = os.getenv("TRUNK_NAME_COLUMN", "").strip().lower()

DATA_DIR = ROOT / "data"
SNAP_DIR = DATA_DIR / "snapshots"
STATE_DIR = ROOT / ".state"          # saved browser session (cookies) so we log in once
for d in (DATA_DIR, SNAP_DIR, STATE_DIR):
    d.mkdir(parents=True, exist_ok=True)

def require_credentials():
    if not USERNAME or not PASSWORD:
        raise SystemExit("Set PORTAL_USERNAME and PORTAL_PASSWORD in .env")
