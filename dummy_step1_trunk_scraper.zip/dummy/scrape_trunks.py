"""Step 1 of Dummy: read trunk names per carrier from the switch portal -> data/trunks.csv

Examples
  python scrape_trunks.py --discover              # save HTML/screenshots of key pages (to tune selectors)
  python scrape_trunks.py --ids 41                # one carrier
  python scrape_trunks.py --ids 1-120             # a range (pages with no trunk table are skipped)
  python scrape_trunks.py --ids 41 --headed       # watch the browser
"""
import argparse, csv, json, time
import config
from parse import extract_trunks, carrier_name
from portal import Portal

def parse_ids(spec: str) -> list[int]:
    ids = []
    for part in spec.split(","):
        if "-" in part:
            a, b = part.split("-"); ids += range(int(a), int(b) + 1)
        else:
            ids.append(int(part))
    return ids

def discover(p: Portal):
    for name, path in [("rate_decks", "rate_decks"),
                       ("carrier_trunks_41", "carrier_trunks?id=41"),
                       ("rate_deck_upload_37", "rate_deck_upload.php?id=37&template=1")]:
        p.goto(path); p.snapshot(name); print("saved", name)
    print(f"Snapshots in {config.SNAP_DIR}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ids", default="41")
    ap.add_argument("--discover", action="store_true")
    ap.add_argument("--headed", action="store_true")
    ap.add_argument("--out", default=str(config.DATA_DIR / "trunks.csv"))
    ap.add_argument("--delay", type=float, default=0.5)
    a = ap.parse_args()

    with Portal(headless=not a.headed) as p:
        if a.discover:
            return discover(p)
        rows, skipped = [], []
        for cid in parse_ids(a.ids):
            html = p.carrier_trunks_html(cid)
            (config.SNAP_DIR / f"carrier_{cid}.html").write_text(html, encoding="utf-8")
            trunks = extract_trunks(html, config.TRUNK_NAME_COLUMN)
            if not trunks:
                skipped.append(cid); print(f"carrier {cid}: no trunk table, skipped"); continue
            cname = carrier_name(html, f"carrier_{cid}")
            for t in trunks:
                rows.append({"carrier_id": cid, "carrier_name": cname, "trunk_name": t["trunk_name"],
                             "trunk_id": t["trunk_id"], "column_guess": t["column_guess"],
                             "raw": json.dumps(t["raw"], ensure_ascii=False)})
            print(f"carrier {cid} ({cname}): {len(trunks)} trunks")
            time.sleep(a.delay)

    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["carrier_id", "carrier_name", "trunk_name", "trunk_id", "column_guess", "raw"])
        w.writeheader(); w.writerows(rows)
    print(f"\nWrote {len(rows)} trunks to {a.out}; skipped carriers: {skipped or 'none'}")
    if any(r["column_guess"] for r in rows):
        print("WARNING: trunk column was guessed (no 'Trunk' header found). Check the CSV / set TRUNK_NAME_COLUMN.")

if __name__ == "__main__":
    main()
