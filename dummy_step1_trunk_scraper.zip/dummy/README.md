# Dummy — step 1: trunk scraper

    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt && playwright install chromium
    cp .env.example .env        # fill in PORTAL_USERNAME / PORTAL_PASSWORD

    python scrape_trunks.py --discover      # saves HTML + screenshots to data/snapshots/
    python scrape_trunks.py --ids 41        # -> data/trunks.csv
    python scrape_trunks.py --ids 1-120     # sweep all carrier ids
    pytest                                   # parser tests (no browser/portal needed)

Selectors are guesses until we see the real pages: if login or the trunk table is not picked up,
send me data/snapshots/*.html (remove any private data) and I'll tune portal.py / parse.py.
