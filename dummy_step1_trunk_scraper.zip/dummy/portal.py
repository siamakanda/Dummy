from playwright.sync_api import sync_playwright, Page, BrowserContext
import config

STATE_FILE = config.STATE_DIR / "state.json"

class Portal:
    """Thin wrapper around the SBC switch portal. All portal-specific knowledge lives here."""

    def __init__(self, headless: bool = True):
        self.headless = headless
        self._pw = self._browser = None
        self.ctx: BrowserContext | None = None
        self.page: Page | None = None

    def __enter__(self):
        config.require_credentials()
        self._pw = sync_playwright().start()
        self._browser = self._pw.chromium.launch(headless=self.headless)
        kw = {"storage_state": str(STATE_FILE)} if STATE_FILE.exists() else {}
        self.ctx = self._browser.new_context(accept_downloads=True, **kw)
        self.page = self.ctx.new_page()
        self.page.set_default_timeout(30_000)
        self.ensure_logged_in()
        return self

    def __exit__(self, *exc):
        try:
            self.ctx.close(); self._browser.close()
        finally:
            self._pw.stop()

    # ---- auth -------------------------------------------------------------
    def _on_login_page(self) -> bool:
        return "/login" in self.page.url or self.page.locator("input[type=password]").count() > 0

    def ensure_logged_in(self):
        self.page.goto(f"{config.BASE_URL}/rate_decks")
        self.page.wait_for_load_state("networkidle")
        if not self._on_login_page():
            return
        self.page.goto(f"{config.BASE_URL}/login")
        self.page.wait_for_load_state("networkidle")
        pw = self.page.locator("input[type=password]").first
        user = self.page.locator(
            "input[name=username], input[name=user], input[name=email], "
            "input[type=text]:visible, input[type=email]:visible").first
        user.fill(config.USERNAME)
        pw.fill(config.PASSWORD)
        pw.press("Enter")
        self.page.wait_for_load_state("networkidle")
        if self._on_login_page():
            self.snapshot("login_failed")
            raise RuntimeError("Login failed (check .env credentials, or CAPTCHA/2FA). See data/snapshots/login_failed.*")
        self.ctx.storage_state(path=str(STATE_FILE))

    # ---- helpers ----------------------------------------------------------
    def goto(self, path: str):
        self.page.goto(f"{config.BASE_URL}/{path.lstrip('/')}")
        self.page.wait_for_load_state("networkidle")
        if self._on_login_page():          # session expired mid-run
            self.ensure_logged_in()
            self.page.goto(f"{config.BASE_URL}/{path.lstrip('/')}")
            self.page.wait_for_load_state("networkidle")

    def show_all_rows(self):
        """If the table is a paginated DataTable, switch page length to the largest option."""
        sel = self.page.locator("select[name$='_length']")
        if sel.count():
            opts = sel.first.locator("option").evaluate_all("els => els.map(e => e.value)")
            nums = [(int(o) if o.lstrip('-').isdigit() else 0, o) for o in opts]
            best = next((o for n, o in nums if n == -1), None) or max(nums)[1]
            sel.first.select_option(best)
            self.page.wait_for_timeout(500)

    def snapshot(self, name: str):
        (config.SNAP_DIR / f"{name}.html").write_text(self.page.content(), encoding="utf-8")
        self.page.screenshot(path=str(config.SNAP_DIR / f"{name}.png"), full_page=True)

    # ---- portal operations ------------------------------------------------
    def carrier_trunks_html(self, carrier_id: int) -> str:
        self.goto(f"carrier_trunks?id={carrier_id}")
        self.show_all_rows()
        return self.page.content()
